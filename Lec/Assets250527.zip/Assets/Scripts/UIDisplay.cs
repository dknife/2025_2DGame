using UnityEngine;

using UnityEngine.UI;
using TMPro;

public class UIDisplay : MonoBehaviour
{
    [SerializeField] Slider healthSlider;
    [SerializeField] Health playerHealth;
    [SerializeField] TextMeshProUGUI scoreText;

    ScoreKeeper scoreKeeper;
    LevelManager levelManager;

    private void Awake()
    {
        levelManager = FindAnyObjectByType<LevelManager>();
    }

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        scoreKeeper = FindAnyObjectByType<ScoreKeeper>();
        if (scoreKeeper != null && scoreText != null)
        {
            scoreText.text = scoreKeeper.GetScore().ToString();
        }
        if (playerHealth != null && healthSlider != null)
        {
            healthSlider.maxValue = playerHealth.GetHealth();
        }
        
    }

    // Update is called once per frame
    void Update()
    {
        healthSlider.value = playerHealth.GetHealth();
        scoreText.text = scoreKeeper.GetScore().ToString();
        if (playerHealth.GetHealth() <= 0)
        {
            levelManager.LoadGameOver();
        }
        else
        {
            Debug.Log($"player health {healthSlider.value}");
        }
    }
}
