using System.Collections;
using UnityEngine;

public class Shooter : MonoBehaviour
{

    [SerializeField] GameObject projectilePrefab;
    [SerializeField] float projectileSpeed = 10f;
    [SerializeField] float projectileLifeTime = 5f;
    [SerializeField] float firingRate = 0.2f;
    [SerializeField] bool autoShoot = false;

    public bool isFiring = false;
    Coroutine firingRoutine;

    AudioPlayer audioPlayer;

    void Awake()
    {
        audioPlayer = FindAnyObjectByType<AudioPlayer>();
    }

    void Start()
    {
        isFiring = true;
    }

    void Update()
    {
        Fire();
    }

    void Fire()
    {
        
        if (isFiring && firingRoutine == null)
        {
            firingRoutine = StartCoroutine(FireContinuously());
            if (audioPlayer != null)
            {
                if (autoShoot)
                {
                    audioPlayer.PlayEnemyShootingClip();
                }
                else
                {
                    audioPlayer.PlayShootingClip();
                }
            }
        }
        else if (!isFiring && firingRoutine != null)
        {
            StopCoroutine(firingRoutine);
            firingRoutine = null;
        }
    }

    IEnumerator FireContinuously()
    {
        while(true)
        {
            // firing action
            GameObject missile = Instantiate(projectilePrefab,
                transform.position, Quaternion.identity);

            Rigidbody2D rb = missile.GetComponent<Rigidbody2D>();
            if (rb != null)
            {
                if (autoShoot) // enemy Shooting
                {
                    rb.linearVelocity = - transform.up * projectileSpeed;
                    
                }
                else // Player Shooting
                {
                    rb.linearVelocity = transform.up * projectileSpeed;
                    
                }
            }

            Destroy(missile, projectileLifeTime);

            float delay = autoShoot ? 4f : 1f;
            yield return new WaitForSeconds(firingRate * delay);
        }
    }
}
