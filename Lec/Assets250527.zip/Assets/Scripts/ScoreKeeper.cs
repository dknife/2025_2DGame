using UnityEngine;

public class ScoreKeeper : MonoBehaviour
{
    int Score = 50;

    // Getter 
    public int GetScore()
    {
        return Score;
    }

    // Score ����
    public void ChangeScore(int value)
    {
        Score += value;
        if (Score < 0)
        {
            Score = 0;
        }
        Debug.Log($"{GetScore()}");
    }

}
