using UnityEngine;

public class AudioPlayer : MonoBehaviour
{
    [SerializeField] AudioClip shootingClip;
    [SerializeField] AudioClip enemyShootingClip;

    [SerializeField] [Range(0f, 1f)] float shootingVolume = 1.0f;

    public void PlayShootingClip()
    {
        if (shootingClip != null)
        {
            AudioSource.PlayClipAtPoint(
                    shootingClip,
                    Camera.main.transform.position,
                    shootingVolume
                );
        }
    }

    public void PlayEnemyShootingClip()
    {
        if (shootingClip != null)
        {
            AudioSource.PlayClipAtPoint(
                    enemyShootingClip,
                    Camera.main.transform.position,
                    shootingVolume
                );
        }
    }
}
