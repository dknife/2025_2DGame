using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using NUnit.Framework;

public class EnemySpawner : MonoBehaviour
{
    [SerializeField] List<WaveConfigSO> waveConfigs;
    [SerializeField] float timeBetweenWaves = 0f;
    [SerializeField] bool isLooping;
    WaveConfigSO currentWave;  // [SerializeField] WaveConfigSO currentWave;

    void Start()
    {
        StartCoroutine(SpawnWaves());    
    }

    public WaveConfigSO GetCurrentWave()
    {
        return currentWave; //  PathFinder�� ������ currentWave�� ���� �ʰ�, �̸� �ҷ��� ����
    }
    // System.Collections �� �ʿ� (IEnumerator�� ����)
    IEnumerator SpawnWaves()
    {
        do
        {
            foreach (WaveConfigSO wave in waveConfigs)
            {
                currentWave = wave;
                for (int i = 0; i < currentWave.GetEnemyCount(); i++)
                {
                    Instantiate(currentWave.GetEnemyPrefab(i),
                                currentWave.GetStartingWaypoint().position,
                                Quaternion.identity,
                                transform);

                    yield return new WaitForSeconds(currentWave.GetRandomSpawnTime());
                }
                yield return new WaitForSeconds(timeBetweenWaves);
            }
        }
        while (isLooping);    
        
    }
}
