using UnityEngine;
using UnityEngine.UIElements;
using System.Collections;

public class ShakeCam : MonoBehaviour
{
    [SerializeField] float shakeDuration = 1f;
    [SerializeField] float shakeMagnitude = 0.5f;

    Vector3 initialPos;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        initialPos = transform.position;
    }

    public void Play()
    {
        StartCoroutine(Shake());
    }

    IEnumerator Shake()
    {
        float eTime = 0f;
        while (eTime < shakeDuration)
        {
            transform.position = initialPos + (Vector3) Random.insideUnitCircle * shakeMagnitude;
            eTime += Time.deltaTime;
            yield return new WaitForEndOfFrame();
        }
        transform.position = initialPos;
    }
}
