using UnityEngine;

public class Health : MonoBehaviour
{
    [SerializeField] int health = 50;
    [SerializeField] ParticleSystem explosion;
    [SerializeField] ParticleSystem damageEffect;

    [SerializeField] bool applyCamShake;

    [SerializeField] bool isPlayer = false;

    ShakeCam shakeCam;
    ScoreKeeper scoreKeeper;

    void Awake()
    {
        shakeCam = Camera.main.GetComponent<ShakeCam>();  
        scoreKeeper = FindAnyObjectByType<ScoreKeeper>();
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        DamageDealer damageDealer = other.GetComponent<DamageDealer>();
        if (damageDealer != null )
        {
            TakeDamage(damageDealer.GetDamage());
            damageDealer.Hit();
        }
    }

    // Getter
    public int GetHealth()
    {
        return health;
    }

    void TakeDamage(int damage)
    {
        health -= damage;

        ShakeCamera();
        if (health <= 0)
        {
            if (explosion != null)
            {
                ExplosionEffect();
            }
            // Score�� �����ؾ� �ϴ� ����
            Die();            
        }
        else
        {
            DamageEffect();
        }
    }

    void Die()
    {
        if ( !isPlayer && scoreKeeper != null) 
        {
            scoreKeeper.ChangeScore(30);
        }
        Destroy(gameObject);
    }

    void ShakeCamera()
    {
        if (shakeCam != null && applyCamShake)
        {
            shakeCam.Play();
        }
    }

    public void DamageEffect()
    {
        ParticleSystem effect = Instantiate(damageEffect, transform.position, Quaternion.identity);

        Destroy(effect.gameObject, effect.main.duration);
    }
    public void ExplosionEffect()
    {
        ParticleSystem effect = Instantiate(explosion, transform.position, Quaternion.identity);

        Destroy(effect.gameObject, effect.main.duration);
    }

}
