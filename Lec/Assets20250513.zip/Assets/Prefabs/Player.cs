using UnityEngine;
using UnityEngine.InputSystem;
public class Player : MonoBehaviour
{
    private Vector2 rawInput;
    private float speed = 5.0f;

    Vector2 minBounds;
    Vector2 maxBounds;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        Camera cam = Camera.main;
        minBounds = cam.ViewportToWorldPoint(new Vector2(0, 0));
        maxBounds = cam.ViewportToWorldPoint(new Vector2(1, 1));
    }

    // Update is called once per frame
    void Update()
    {
        Vector2 moveDelta = rawInput * speed * Time.deltaTime;
        Vector2 newPosition = (Vector2) transform.position + moveDelta; 

        newPosition.x = Mathf.Clamp(newPosition.x, minBounds.x, maxBounds.x); 
        newPosition.y = Mathf.Clamp(newPosition.y, minBounds.y, maxBounds.y);
        transform.position = newPosition;
    }

    public void OnMove(InputAction.CallbackContext context)
    {
        if (context.performed)
        {
            rawInput = context.ReadValue<Vector2>();
        }
        else if (context.canceled)
        {
            rawInput = new Vector2(0.0f, 0.0f);
        }
    }

    
    Shooter shooter = null;
    private void Awake()
    {
        shooter = GetComponent<Shooter>();
    }

    public void OnAttack(InputAction.CallbackContext context)
    {
        if (context.performed)
        {
            if (shooter != null)
            {
                shooter.isFiring = true;
            }
        }
        else if (context.canceled)
        {
            if (shooter != null)
            {
                shooter.isFiring = false;
            }
        }
    }
    
}
