using UnityEngine;

public class Health : MonoBehaviour
{
    [SerializeField] int health = 50;
    [SerializeField] ParticleSystem explosion;
    [SerializeField] ParticleSystem damageEffect;

    [SerializeField] bool applyCamShake;

    [SerializeField] bool isPlayer = false;
    ShakeCam shakeCam;

    AudioPlayer audioPlayer;

    void Awake()
    {
        shakeCam = Camera.main.GetComponent<ShakeCam>();   
        audioPlayer = FindAnyObjectByType<AudioPlayer>();
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        DamageDealer damageDealer = other.GetComponent<DamageDealer>();
        if (damageDealer != null )
        {
            TakeDamage(damageDealer.GetDamage());
            damageDealer.Hit();
        }
    }

    void TakeDamage(int damage)
    {
        health -= damage;

        ShakeCamera();
        if (health <= 0)
        {
            if (explosion != null)
            {
                ExplosionEffect();
            }
            Destroy(gameObject);
        }
        else
        {
            DamageEffect();
        }
    }

    void ShakeCamera()
    {
        if (shakeCam != null && applyCamShake)
        {
            shakeCam.Play();
        }
    }

    public void DamageEffect()
    {
        ParticleSystem effect = Instantiate(damageEffect, transform.position, Quaternion.identity);

        Destroy(effect.gameObject, effect.main.duration);
    }
    public void ExplosionEffect()
    {
        ParticleSystem effect = Instantiate(explosion, transform.position, Quaternion.identity);

        Destroy(effect.gameObject, effect.main.duration);

        if (audioPlayer != null && isPlayer)
        {
            audioPlayer.PlayExplosionClip();
        }
        
    }

}
